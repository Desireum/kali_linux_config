declare const Rs: IRs = {}

interface IRs {
  File: IRsFile
  Text: IRsText
}

interface IRsFile {
  IDR_FEATURE_SWITCH: string
}

interface IRsText {
  IDS_LARK_PRODUCT_NAME: string
  IDS_TAB_SPACE: string
  IDS_TAB_MESSENGER: string
  IDS_TAB_MAIL: string
  IDS_TAB_CALENDAR: string
  IDS_TAB_CONTACTS: string
  IDS_TAB_WORKPLACE: string
}
