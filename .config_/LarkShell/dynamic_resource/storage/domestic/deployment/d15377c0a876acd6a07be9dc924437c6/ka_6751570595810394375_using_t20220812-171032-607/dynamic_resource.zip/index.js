import { get } from '../index';

const Rs = {
  File: {
    IDR_FEATURE_SWITCH: get('IDR_FEATURE_SWITCH.file')
  },
  Text: {
    IDS_LARK_PRODUCT_NAME: get('IDS_LARK_PRODUCT_NAME.text'),
    IDS_TAB_SPACE: get('IDS_TAB_SPACE.text'),
    IDS_TAB_MESSENGER: get('IDS_TAB_MESSENGER.text'),
    IDS_TAB_MAIL: get('IDS_TAB_MAIL.text'),
    IDS_TAB_CALENDAR: get('IDS_TAB_CALENDAR.text'),
    IDS_TAB_CONTACTS: get('IDS_TAB_CONTACTS.text'),
    IDS_TAB_WORKPLACE: get('IDS_TAB_WORKPLACE.text')
  }
};

export default Rs;
